#!/bin/sh
	usb umount $1
	echo "usb umount $1" > /dev/console
exit 1
